
#ifndef CHALLENGE_H
#define CHALLENGE_H

char *challenge(char *str);

#endif
