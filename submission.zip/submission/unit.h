
#ifndef UNIT_H
#define UNIT_H

/*
 * 0 if passed, 1 if failed
 */
int unit_test(char *input, char *expected);

#endif
